class Primitives{
    public static void main(String[] args) {
        int rollno=2; // using for integer values 

        //char let="n"; //using for charter /string

        float marks= 98.23f; //using for float values 
                            // In the end of the number we wil put f 
        double LargerDecimalNumbers=233.23421;

        long LargerInterger =1234567;//using for large number of Integers

    }
}