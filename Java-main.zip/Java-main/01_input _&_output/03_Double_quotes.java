 class Double_qyotes {
   public static void main(String[] args) {
        System.out.println(  " \" Java\" ");// '\"' is used to print Double Quotes (")

    }

}
