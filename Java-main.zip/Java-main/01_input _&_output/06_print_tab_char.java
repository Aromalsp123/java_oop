 class Print_tab_char {
    public static void main(String[] args) {
        System.out.println("\t hello \t how are you ");
    }
    
}
