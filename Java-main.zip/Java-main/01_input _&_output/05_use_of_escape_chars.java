 class Use_of_escape_chars {
    public static void main(String[] args) {
        System.out.println("\\\"Hello, this is  forward slash (/), this is back slash (\\\\), this is single quote (') and this is double quote (\\\")");
    }
    
}
