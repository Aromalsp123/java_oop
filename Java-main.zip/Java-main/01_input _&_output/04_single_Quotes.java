 class single_Quotes {
    public static void main(String agr[]){
        System.out.println(" 'hello' ");
    }
    
}
