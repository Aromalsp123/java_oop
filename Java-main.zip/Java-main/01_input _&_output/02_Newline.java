 class Newline {
    public static void main(String ard[]){
       
        System.out.print(" Hello \n How can i help you \n "); // n is used for print a new line

        // or we can use println()

        System.out.println("hey");
        System.out.println("hey");



        //print *
        System.out.println("");
        System.out.println("*");
        System.out.println("* *");
        System.out.println("* * *");
        System.out.println("* * * *");
    }
    
}
