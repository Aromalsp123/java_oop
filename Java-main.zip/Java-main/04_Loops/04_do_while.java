class do_while {
    public static void main(String[] args) {
        int n=1;
        do { 
            System.out.println("hello");
            
        } while (n != 1);

        //once it will exicute then only check the condition

       


        


    }
    
}
