 class basic_whlie_loop {
    public static void main(String[] args) {
    
     
        
        //while loop
        /*
        Syntax
           
            while(condion){

                //body 

            }

         */
        int i=1;
        while(i<=5){
            System.out.println("HELLO");
            i++;
        }

        //NOTE
        /*while loop is basicly using when we don't know 
            how many time the loop is going to run
                       */

    }

    
    
}
