class basic_for_loop{
    public static void main(String[] args) {
        /*
         Syntax of for loops:
            for(inirilasation ;condition ;increment/decrement){
                    //body
            
            }
         */
        //print number from 1 to 5 

        for(int i=1;i<=5;i++){
            System.out.println(i);
        }

        System.err.println("");

        //to print hello fro 5 times

        for (int i = 0; i < 5; i++) {
            System.out.println("hello ");
            
        }

       
    }
}